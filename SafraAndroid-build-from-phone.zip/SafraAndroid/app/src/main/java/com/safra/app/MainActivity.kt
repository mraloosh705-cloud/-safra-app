package com.safra.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Locale

private val SafraGreen = Color(0xFF167D4A)
private val SafraCream = Color(0xFFFFF8EE)
private val SafraOrange = Color(0xFFFFA53D)

data class Meal(
    val id: Int,
    val name: String,
    val restaurant: String,
    val description: String,
    val price: Double,
    val emoji: String
)

data class CartLine(val meal: Meal, val quantity: Int)

private val sampleMeals = listOf(
    Meal(1, "برغر كلاسيك", "برغر هاوس", "لحم مشوي، جبنة، خس وصوص خاص", 3.50, "🍔"),
    Meal(2, "بيتزا خضار", "بيتزا تايم", "جبنة موزاريلا وخضار طازجة", 5.00, "🍕"),
    Meal(3, "وجبة شاورما دجاج", "شاورما البلد", "شاورما دجاج مع بطاطا ومخلل", 2.75, "🌯"),
    Meal(4, "وجبة بروستد", "دجاج كرسبي", "دجاج مقرمش مع بطاطا وثوم", 4.25, "🍗"),
    Meal(5, "سلطة سيزر", "جرين بايت", "خس، دجاج، خبز محمص وصوص سيزر", 3.00, "🥗"),
    Meal(6, "كنافة", "حلويات الشام", "كنافة ساخنة بالجبنة والقطر", 2.00, "🍰")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SafraApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafraApp() {
    var cart by remember { mutableStateOf(mapOf<Int, CartLine>()) }
    var currentTab by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var payment by remember { mutableStateOf("الدفع عند الاستلام") }
    var orderMessage by remember { mutableStateOf<String?>(null) }

    val filteredMeals = sampleMeals.filter {
        it.name.contains(search, ignoreCase = true) ||
        it.restaurant.contains(search, ignoreCase = true)
    }
    val subtotal = cart.values.sumOf { it.meal.price * it.quantity }
    val deliveryFee = if (cart.isEmpty()) 0.0 else 0.75
    val total = subtotal + deliveryFee
    val money = { amount: Double -> String.format(Locale.US, "%.2f د.أ", amount) }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = SafraGreen,
            secondary = SafraOrange,
            background = SafraCream,
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("سفرة", fontWeight = FontWeight.ExtraBold, fontSize = 25.sp)
                            Text("أكلك المفضل، لباب بيتك", fontSize = 12.sp, color = Color.Gray)
                        }
                    },
                    actions = {
                        IconButton(onClick = { currentTab = "cart" }) {
                            BadgedBox(badge = {
                                if (cart.values.sumOf { it.quantity } > 0) {
                                    Badge { Text(cart.values.sumOf { it.quantity }.toString()) }
                                }
                            }) { Icon(Icons.Default.ShoppingCart, contentDescription = "السلة") }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = SafraCream)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = currentTab == "home",
                        onClick = { currentTab = "home" },
                        icon = { Icon(Icons.Default.Restaurant, contentDescription = null) },
                        label = { Text("الرئيسية") }
                    )
                    NavigationBarItem(
                        selected = currentTab == "cart",
                        onClick = { currentTab = "cart" },
                        icon = { Icon(Icons.Default.ShoppingCart, contentDescription = null) },
                        label = { Text("السلة") }
                    )
                    NavigationBarItem(
                        selected = currentTab == "orders",
                        onClick = { currentTab = "orders" },
                        icon = { Text("📦") },
                        label = { Text("طلباتي") }
                    )
                }
            },
            containerColor = SafraCream
        ) { padding ->
            when (currentTab) {
                "home" -> HomeScreen(
                    modifier = Modifier.padding(padding),
                    search = search,
                    onSearchChange = { search = it },
                    meals = filteredMeals,
                    onAdd = { meal ->
                        val old = cart[meal.id]
                        cart = cart + (meal.id to CartLine(meal, (old?.quantity ?: 0) + 1))
                        orderMessage = null
                    },
                    money = money
                )
                "cart" -> CartScreen(
                    modifier = Modifier.padding(padding),
                    cart = cart,
                    money = money,
                    subtotal = subtotal,
                    deliveryFee = deliveryFee,
                    total = total,
                    payment = payment,
                    onPaymentChange = { payment = it },
                    onChangeQuantity = { meal, delta ->
                        val old = cart[meal.id] ?: return@CartScreen
                        val next = old.quantity + delta
                        cart = if (next <= 0) cart - meal.id
                        else cart + (meal.id to old.copy(quantity = next))
                    },
                    onCheckout = {
                        if (cart.isNotEmpty()) {
                            orderMessage = "تم تسجيل طلبك التجريبي بنجاح. طريقة الدفع: $payment"
                            cart = emptyMap()
                            currentTab = "orders"
                        }
                    }
                )
                else -> OrdersScreen(Modifier.padding(padding), orderMessage)
            }
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier,
    search: String,
    onSearchChange: (String) -> Unit,
    meals: List<Meal>,
    onAdd: (Meal) -> Unit,
    money: (Double) -> String
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SafraGreen),
                shape = RoundedCornerShape(22.dp)
            ) {
                Column(Modifier.fillMaxWidth().padding(20.dp)) {
                    Text("جعان؟ 😋", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text("اختار وجبتك وخلي الباقي علينا", color = Color.White)
                    Spacer(Modifier.height(12.dp))
                    Text("رسوم توصيل تجريبية: 0.75 د.أ", color = Color(0xFFE6F5EB), fontSize = 12.sp)
                }
            }
        }
        item {
            OutlinedTextField(
                value = search,
                onValueChange = onSearchChange,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("ابحث عن وجبة أو مطعم") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )
        }
        item { Text("وجبات مقترحة", fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        if (meals.isEmpty()) {
            item { Text("ما لقينا نتائج. جرّب كلمة ثانية.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
        }
        items(meals, key = { it.id }) { meal ->
            MealCard(meal = meal, money = money, onAdd = { onAdd(meal) })
        }
    }
}

@Composable
private fun MealCard(meal: Meal, money: (Double) -> String, onAdd: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier.size(76.dp).background(SafraCream, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) { Text(meal.emoji, fontSize = 36.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(meal.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(meal.restaurant, color = SafraGreen, fontSize = 12.sp)
                Text(meal.description, color = Color.Gray, fontSize = 11.sp, maxLines = 2)
                Spacer(Modifier.height(5.dp))
                Text(money(meal.price), color = SafraGreen, fontWeight = FontWeight.Bold)
            }
            IconButton(onClick = onAdd) {
                Icon(Icons.Default.Add, contentDescription = "أضف للسلة", tint = SafraGreen)
            }
        }
    }
}

@Composable
private fun CartScreen(
    modifier: Modifier,
    cart: Map<Int, CartLine>,
    money: (Double) -> String,
    subtotal: Double,
    deliveryFee: Double,
    total: Double,
    payment: String,
    onPaymentChange: (String) -> Unit,
    onChangeQuantity: (Meal, Int) -> Unit,
    onCheckout: () -> Unit
) {
    Column(
        modifier = modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("سلة المشتريات", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        if (cart.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🛒", fontSize = 52.sp)
                    Text("السلة فاضية", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("أضف وجبات من الصفحة الرئيسية")
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(cart.values.toList(), key = { it.meal.id }) { line ->
                    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                        Row(
                            Modifier.fillMaxWidth().padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(line.meal.emoji, fontSize = 28.sp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(line.meal.name, fontWeight = FontWeight.Bold)
                                Text(money(line.meal.price * line.quantity), color = SafraGreen)
                            }
                            IconButton(onClick = { onChangeQuantity(line.meal, -1) }) {
                                Icon(Icons.Default.Remove, contentDescription = "تقليل الكمية")
                            }
                            Text(line.quantity.toString(), fontWeight = FontWeight.Bold)
                            IconButton(onClick = { onChangeQuantity(line.meal, 1) }) {
                                Icon(Icons.Default.Add, contentDescription = "زيادة الكمية")
                            }
                        }
                    }
                }
            }
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    PriceRow("المجموع الفرعي", money(subtotal))
                    PriceRow("التوصيل", money(deliveryFee))
                    HorizontalDivider()
                    PriceRow("الإجمالي", money(total), bold = true)
                    Text("طريقة الدفع", fontWeight = FontWeight.Bold)
                    listOf("الدفع عند الاستلام", "بطاقة إلكترونية (تجريبي)").forEach { option ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = payment == option, onClick = { onPaymentChange(option) })
                            Text(option)
                        }
                    }
                    Button(
                        onClick = onCheckout,
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text("تأكيد الطلب • ${money(total)}") }
                    Text(
                        "ملاحظة: إنشاء الطلب هنا محلي وتجريبي، ولا يتم تحصيل أي مبلغ.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun PriceRow(label: String, amount: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(amount, color = if (bold) SafraGreen else Color.DarkGray, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun OrdersScreen(modifier: Modifier, orderMessage: String?) {
    Column(
        modifier = modifier.fillMaxSize().padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("طلباتي", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        if (orderMessage == null) {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("📦", fontSize = 48.sp)
                    Text("ما عندك طلبات لحد الآن", fontWeight = FontWeight.Bold)
                    Text("لما تأكد طلب رح تظهر حالته هون.", color = Color.Gray)
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("طلب تجريبي جديد", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(orderMessage)
                    listOf("تم استلام الطلب", "قيد التحضير", "خرج للتوصيل", "تم التسليم").forEachIndexed { index, status ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (index == 0) "🟢" else "⚪", fontSize = 16.sp)
                            Spacer(Modifier.width(8.dp))
                            Text(status)
                        }
                    }
                    Text("الحالات المعروضة توضيحية وليست تحديثات مباشرة من مطعم أو مندوب.", color = Color.Gray, fontSize = 11.sp)
                }
            }
        }
    }
}
